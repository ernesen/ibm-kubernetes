sudo ifconfig lo0 10.0.2.2 alias
